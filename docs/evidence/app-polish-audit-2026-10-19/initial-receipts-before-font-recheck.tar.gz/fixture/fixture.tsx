import React, { useState } from 'react';
import {createRoot} from 'react-dom/client';
import {ConfirmDialog} from '../../src/components/ui/Dialog';
import {Field, TextInput} from '../../src/components/ui/Form';
import {GeminiProgressView} from '../../src/pages/StudyLibrary/GeminiJobNotice';
import type {GeminiJob} from '../../src/state/GeminiJobs';
import '@fontsource-variable/fraunces/opsz.css';
import '@fontsource/inter/latin-400.css';
import '../../src/styles/tokens.css';
import '../../src/styles/base.css';
import '../../src/components/ui/ui.css';
import '../../src/pages/StudyLibrary/studyLibrary.css';
const params=new URLSearchParams(location.search);
if(params.has('large')) document.documentElement.style.fontSize='24px';
if(params.has('fallback')) HTMLDialogElement.prototype.showModal=undefined as never;
function Fixture(){
 const [open,setOpen]=useState(true); const [sent,setSent]=useState(0);
 const mode=params.get('mode');
 if(mode==='progress')return <main style={{padding:24,maxWidth:390}}><h1>Generation progress</h1><GeminiProgressView title="Creating your study guide" job={{key:'synthetic',kind:'study-aid',phase:'running',stage:'generating',startedAt:Date.now()-5000,progress:'Synthetic_document_identifier_'.repeat(7)} as GeminiJob} onCancel={()=>setOpen(false)}/><p>{open?'Running':'Cancelled'}</p></main>;
 if(mode==='field')return <main style={{padding:24}}><h1>Form feedback</h1><Field label="Title" hint="Choose a descriptive name" error="Enter a title"><TextInput /></Field></main>;
 return <main><h1>Confirmation fixture</h1><p>Provider sends: {sent}</p><ConfirmDialog open={open} title="Send this file to Google?" message="Synthetic fixture. No provider or profile is connected." confirmLabel="Send to Gemini" secondaryLabel="Choose a chapter or pages first" destructive={false} onSecondary={()=>setOpen(false)} onConfirm={()=>setSent(sent+1)} onCancel={()=>setOpen(false)}/></main>;
}
createRoot(document.getElementById('root')!).render(<Fixture/>);
