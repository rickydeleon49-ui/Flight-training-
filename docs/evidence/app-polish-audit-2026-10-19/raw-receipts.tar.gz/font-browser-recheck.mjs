import {createRequire} from 'node:module';
import {execSync} from 'node:child_process';
import {writeFile} from 'node:fs/promises';
const require=createRequire(execSync('npm root -g').toString().trim()+'/_');
const {chromium}=require('playwright');
const browser=await chromium.launch({headless:true,channel:"chrome"});
const context=await browser.newContext();
const page=await context.newPage();
const base='http://127.0.0.1:5197';
const out='/Users/rickymac/.codex/task-recovery/app-polish-audit-20261019';
const results={browserVersion:browser.version(),routes:[],confirmations:[],shortKeyboard:[],errors:[],fontResponses:[]};
page.on('pageerror',error=>results.errors.push(error.message));
page.on('response',r=>{if(/\.(woff2?|ttf)(\?|$)/.test(r.url()))results.fontResponses.push({status:r.status(),url:r.url()});});
async function readyFonts(needDisplay=true){await page.evaluate(async()=>{await document.fonts.ready;});const fonts=await page.evaluate(()=>Array.from(document.fonts).filter(f=>f.status==='loaded').map(f=>f.family));if(!fonts.includes('Inter')||(needDisplay&&!fonts.includes('Fraunces Variable')))throw Error('Required bundled fonts not loaded: '+JSON.stringify(fonts));return [...new Set(fonts)];}
try{
 for(const width of [390,1280]){
  await page.setViewportSize({width,height:900});
  for(const route of ['/','/flight-path','/study','/schedule','/journal','/questions','/notes','/finances','/toolkit','/settings']){
   await page.goto(base+'/#'+route);await page.locator('main h1').waitFor();const fonts=await readyFonts();
   results.routes.push({route,width,fonts,...await page.evaluate(()=>({title:document.querySelector('main h1').textContent,scrollWidth:document.documentElement.scrollWidth,overflowingControls:Array.from(document.querySelectorAll('main button,main input,main textarea,main select')).filter(e=>{const r=e.getBoundingClientRect();return r.width>0&&(r.left< -1||r.right>innerWidth+1)}).map(e=>e.textContent.slice(0,60))}))});
  }
 }
 for(const cfg of [{width:390,height:844,large:false,fallback:false},{width:390,height:844,large:true,fallback:false},{width:390,height:480,large:true,fallback:false},{width:390,height:844,large:true,fallback:true},{width:1280,height:900,large:false,fallback:false}]){
  await page.setViewportSize({width:cfg.width,height:cfg.height});await page.goto(base+'/screenshots/polish-audit/fixture.html?'+(cfg.large?'large=1&':'')+(cfg.fallback?'fallback=1':''));await page.getByRole('dialog').waitFor();const fonts=await readyFonts();
  const geometry=await page.locator('dialog').evaluate(d=>{let r=d.getBoundingClientRect();return {buttons:Array.from(d.querySelectorAll('button')).map(e=>{let b=e.getBoundingClientRect();return {label:e.textContent,left:b.left,right:b.right,inside:b.left>=r.left&&b.right<=r.right}})}});
  if(geometry.buttons.some(b=>!b.inside))throw Error('Clipped action '+JSON.stringify(cfg));
  results.confirmations.push({...cfg,fonts,...geometry});
  if(cfg.width===390&&!cfg.large){await page.getByRole('dialog').screenshot({path:out+'/confirmation-after-fonts.jpg'});}
  await page.getByRole('button',{name:'Cancel',exact:true}).click();await page.getByRole('dialog').waitFor({state:'hidden'});await page.getByText('Provider sends: 0',{exact:true}).waitFor();
 }
 for(const fallback of [false,true]){
  await page.setViewportSize({width:390,height:480});await page.goto(base+'/screenshots/polish-audit/fixture.html?large=1'+(fallback?'&fallback=1':''));await page.getByRole('dialog').waitFor();await readyFonts();
  await page.getByRole('button',{name:'Choose a chapter or pages first'}).press('Tab');
  const g=await page.evaluate(()=>{let r=document.querySelector('dialog').getBoundingClientRect(),a=document.activeElement,b=a.getBoundingClientRect();return {focused:a.textContent,visible:b.top>=r.top&&b.bottom<=r.bottom}});
  if(g.focused!=='Send to Gemini'||!g.visible)throw Error('Keyboard action clipped');results.shortKeyboard.push({fallback,...g});await page.keyboard.press('Escape');await page.getByRole('dialog').waitFor({state:'hidden'});
 }
 await page.setViewportSize({width:390,height:844});await page.goto(base+'/screenshots/polish-audit/fixture.html?mode=progress');await page.getByRole('heading',{name:'Generation progress'}).waitFor();await readyFonts(false);
 results.progress=await page.evaluate(()=>({width:innerWidth,scrollWidth:document.documentElement.scrollWidth,status:document.querySelector('[role=status]').textContent}));
 if(results.progress.scrollWidth>390)throw Error('Progress overflow');await page.screenshot({path:out+'/progress-after-fonts.jpg'});
 await page.goto(base+'/screenshots/polish-audit/fixture.html?mode=field');await page.getByRole('textbox',{name:'Title'}).waitFor();
 results.field=await page.getByRole('textbox',{name:'Title'}).evaluate(e=>({references:e.getAttribute('aria-describedby').split(' ').map(id=>({id,exists:!!document.getElementById(id)}))}));
 if(results.field.references.some(r=>!r.exists))throw Error('Missing field description');
 if(results.errors.length||results.fontResponses.some(r=>![200,304].includes(r.status))||results.routes.some(r=>r.overflowingControls.length))throw Error('Browser error, blocked font or overflowing route: '+JSON.stringify({errors:results.errors,fonts:results.fontResponses.filter(r=>![200,304].includes(r.status)),routes:results.routes.filter(r=>r.overflowingControls.length)}));
 results.pass=true;await writeFile(out+'/font-browser-checks.json',JSON.stringify(results,null,2));console.log(JSON.stringify({pass:true,routes:results.routes.length,dialogs:results.confirmations.length,shortKeyboard:results.shortKeyboard.length,loadedFonts:results.routes[0].fonts,errors:results.errors}));
}catch(error){await writeFile(out+'/font-browser-failed-checks.json',JSON.stringify(results,null,2));throw error;}finally{await context.close();await browser.close();}
